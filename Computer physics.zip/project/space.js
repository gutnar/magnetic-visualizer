/**
 Space
 */

var Space = function (canvasId) {
    // Canvas
    this.canvas = document.getElementById('space');
    this.ctx = this.canvas.getContext('2d');

    // Magnetic permeability (mT * cm / A)
    this.mu = 4*Math.PI/10000;

    // Objects
    this.objects = [];
};

/**
 * Add object
 */

Space.prototype.add = function (object) {
    this.objects.push(object);
};

/**
 * Get the magnetic field vector at a given point
 * @param {Vector} point
 * @param {SpaceObject} excludeObject - object to exclude in calculation
 * @returns {Vector}
 */

Space.prototype.getMagneticField = function (point, excludeObject) {
    // Initial value
    var B = new Vector(0, 0);

    // Add fields of objects in space
    for (var i = 0; i < this.objects.length; ++i) {
        if (this.objects[i] !== excludeObject) {
            B.add(this.objects[i].getMagneticField(point));
        }
    }

    // Return magnetic field vector
    return B;
};

/**
 * Draw field line that goes through given point
 * @param {Vector} start
 */

Space.prototype.drawFieldLine = function (start) {
    // Start line
    this.ctx.beginPath();
    this.ctx.moveTo(start.x, start.y);

    // Current point along line
    var point = start.clone();

    // Magnetic field vector
    var B;

    // Closing status
    var closing = false;

    // Move along line
    for (var i = 0; i < 100000; ++i) {
        // Get magnetic field vector at point
        B = this.getMagneticField(point);

        // Move along field line
        point.add(B.normalize().multiply(0.2));

        // Draw segment of field line
        this.ctx.lineTo(point.x, point.y);

        // Moved away from start point - begin to try and close the line
        if (!closing && point.getDistanceSq(start) > 2) {
            closing = true;
        }

        // Near finish point - try and close the line
        else if (closing && point.getDistanceSq(start) < 2) {
            break;
        }

        //console.log(point);
    }

    // End line
    this.ctx.strokeStyle = '#00ffff';
    this.ctx.stroke();
};

/**
 * Draw field lines
 */

Space.prototype.drawFieldLines = function () {
    this.drawFieldLine(new Vector(250, 300));
    this.drawFieldLine(new Vector(300, 300));
    this.drawFieldLine(new Vector(350, 300));
    this.drawFieldLine(new Vector(400, 300));
    this.drawFieldLine(new Vector(450, 300));
};

/**
 * Render
 */

Space.prototype.render = function () {
    // Time since last render
    if (this.time) {
        this.delta = new Date().getTime()/1000 - this.time;
    } else {
        this.time = new Date().getTime()/1000;
    }

    // Clear canvas
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // Render objects
    for (var i = 0; i < this.objects.length; ++i) {
        this.objects[i].render(this.ctx);
    }

    // Draw field lines
    this.drawFieldLines();

    // Pass time
    if (this.delta) {
        this.time += this.delta;
    }
};

/**
 * Get object at given position
 * @param x
 * @param y
 */

Space.prototype.getObjectAt = function (x, y) {
    // Try to find object at given position
    for (var i = 0; i < this.objects.length; ++i) {
        if (this.objects[i].hitTest(this.objects[i].x - x, this.objects[i].y - y)) {
            return this.objects[i];
        }
    }
};