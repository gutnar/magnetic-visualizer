// Create a space
var space = new Space('space');

// Make canvas size equal to entire window size
window.onresize = function () {
    space.canvas.width = window.innerWidth;
    space.canvas.height = window.innerHeight;
    space.render();
};

// Interaction
var dragging = null;

space.canvas.onmousedown = function (e) {
    dragging = space.getObjectAt(e.x, e.y);
    space.render();
};

space.canvas.onmouseup = function () {
    dragging = null;
};

space.canvas.onmousemove = function (e) {
    if (dragging) {
        dragging.x = e.x;
        dragging.y = e.y;

        space.render();
    }
};

// Start time
var start = new Date;

// Test
new StraightWire(space, 510, 200, {current: 1});
new StraightWire(space, 800, 200, {current: 1, period: 30, phase: Math.PI});
new StraightWire(space, 550, 450, {current: 1, period: 5});

// Render
window.onresize();

// Render loop
setInterval(function () {
    space.render();
}, 50);

// Computation time
console.log(new Date - start);